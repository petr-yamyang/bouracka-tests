# Manifest — Automation balíček v0.3.0 — 2026-05-06

> Runnable automation suite. Po rozbalení následujte
> `INSTALL-FROM-ZERO-v0.3-CS.md` (totožný soubor je i v analytickém balíčku).

## §1. Soubory (automation-v0.3.0)

| Soubor | Velikost (B) | SHA256 |
|--------|--------------|--------|
| `INSTALL-FROM-ZERO-v0.3-CS.md` | 9215 | `f29800fb5b80de07126972bcb5c06e700f18a3ec712462e30476a53c798558bf` |
| `bouracka-tests-v0.3.0.tar.gz` | 1163064 | `8867dc4a9399165495732490f0e591e86d0cf0df36d7a17558e4729f90ef6e4f` |
| `bouracka-tests-v0.3.0.zip` | 1238221 | `3917275a91fa1bc63ef6e77125d6a83c59ef56d9037a5af7dc59cc2dad6e167b` |
| **TOTAL** | **2 410 500 B (≈2.30 MB)** | — |

> Tarball + ZIP obsahují identický obsah; volba podle preferovaného nástroje na rozbalení.

## §2. Co je uvnitř `bouracka-tests-v0.3.0.zip`

Ekvivalent struktury repozitáře, **bez** archivu, node_modules, výstupů
testů a DEMO intel zachycení. Klíčové složky:

```
bouracka-tests/
├── BOURACKA-TESTPLAN-v0.3.xlsx           ← test-plán (28 TT, 48 TC)
├── _install/INSTALL-FROM-ZERO-v0.3-CS.md ← instalační příručka
├── _specs/                               ← formát specifikace + lessons learned
├── playwright/
│   ├── playwright.config.ts
│   ├── tests/
│   │   ├── bring-up-smoke.spec.ts        ← TC-CP-001
│   │   ├── core-flow.spec.ts
│   │   ├── login.spec.ts
│   │   └── intel-probes/                 ← CP-SUPIN-04 STEP 14
│   │       ├── 01-enumeration-dump.spec.ts
│   │       ├── 02-codelist-scrape.spec.ts
│   │       └── README-OPERATOR.md
│   └── runtime/spec-loader.ts
├── cypress/                              ← scaffolding pro CP-SUPIN-05
├── testcafe/                             ← scaffolding pro CP-SUPIN-05
├── recon/
│   ├── ANALYTICAL-DOC-INTELLIGENCE-v0.3.md
│   ├── DELTA-DEMO-vs-PROD-v0.1.md
│   ├── DEMO-PUBLIC-LIVE-2026-05-06.md
│   ├── integrations/INT-001..INT-009.md
│   └── screenflows-live/flow-A1-main-tst-demo/
│       ├── flow.md
│       ├── photos/                       ← prázdná (PROD photos pending)
│       ├── snippets/                     ← prázdná
│       └── uml/{use-case,activity,sequence}.puml
├── fixtures/
│   ├── codelists.yaml                    ← analytical-doc skeleton
│   ├── codelists-live-2026-05-06.yaml    ← live-captured
│   ├── api-endpoints-live-2026-05-06.yaml
│   ├── live-copy-strings.yaml
│   └── field-definitions.yaml
├── mockoon/n8-sms-gateway.json           ← mock profil pro PROD
├── tools/
│   ├── validate_workbook.py              ← 10-check validátor
│   ├── migrate_to_v03.py                 ← v0.2 → v0.3 migrace
│   ├── generate_tests.py                 ← code-gen z Excel
│   ├── test_console.py + test-console.ps1 ← multi-framework runner
│   ├── render-uml.ps1                    ← PlantUML → PNG/SVG
│   ├── build_mindmaps.py                 ← TT/TC mindmap diagramy
│   └── heic-to-jpg.{ps1,sh}              ← konverze fotek
├── scripts/
│   ├── run-bring-up-smoke.ps1
│   ├── run-playwright.ps1
│   ├── run-cypress.ps1
│   ├── run-testcafe.ps1
│   ├── run-all.ps1
│   ├── setup-from-zero.ps1               ← one-shot Profile-C install
│   ├── validate-install.ps1              ← 14 zdravotních kontrol
│   └── package-deliverable.ps1
├── package.json
└── tsconfig.json
```

## §3. Verifikace integrity ZIP

PowerShell:

```pwsh
Get-FileHash bouracka-tests-v0.3.0.zip -Algorithm SHA256
# očekávaný: 3917275a91fa1bc63ef6e77125d6a83c59ef56d9037a5af7dc59cc2dad6e167b
```

## §4. Email transport

Velikost balíčku **2.3 MB** se vejde do jediného e-mailu (limit
většiny korporátních systémů je 10 MB nebo 25 MB). **Bez split na volumes.**

Pokud korporátní filtr blokuje `.zip`/`.tar.gz`:
- přejmenujte na `.zib` nebo přidejte `.txt` suffix
- nebo využijte SharePoint / Box odkaz

## §5. Status

| Item | Hodnota |
|------|---------|
| Verze | v0.3.0 |
| Datum | 2026-05-06 |
| Velikost | 2.30 MB (1 e-mail) |
| Email-volume split | NE |
| Runnable po rozbalení | ANO (po §2 + §5 Profile-C install) |
