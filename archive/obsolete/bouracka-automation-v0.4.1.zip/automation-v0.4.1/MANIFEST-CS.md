# Manifest — Bouračka automation balíček v0.4.1 — 2026-05-06

## §1. Soubory

| Soubor | Velikost (B) | SHA256 |
|--------|--------------|--------|
| `INSTALL-FROM-ZERO-v0.4-CS.md` | 13222 | `935754359c41b5d076e43af431d5a0318ec063235b5abba7b9a0fd36f8f51d13` |
| `bouracka-tests-v0.4.1.zip` | 1535842 | `6e5306740f2d82db442f1baa5f6fc21c8117878719854f7e3348b2f881f39c6b` |
| **TOTAL** | **1549064** | — |

## §2. Co je nového vs v0.3.0

- **NEW** master Excel `BOURACKA-TESTPLAN-v0.4.0.xlsx` (branch tagging)
- **NEW** `scripts/sanity-check.ps1` (7-check post-install verifier)
- **NEW** `tools/{check_priority_matrix,fix_priority_matrix,bump_workbook_version,migrate_to_v04_branch_tagging,render_branch_doc}.py`
- **NEW** v0.4 install guide (5 empirický gotchas přesunutých na preflight)
- **NEW** `recon/ANALYTICAL-DOC-MASTER-v0.4.md` (branched master)
- **NEW** `_specs/BRANCHED-MASTER-DOC-PATTERN-v0.1.md`
- **NEW** branch-aware suite scaffolds in `delivery/suite-DEMO-v0.3.0`, `delivery/suite-PROD-v0.3.0`
  (in repo, not in this zip — see analytical-v0.4.1 for separate suite ZIPs)

## §3. Stav

| Item | Hodnota |
|------|---------|
| Verze | v0.4.1 |
| Datum | 2026-05-06 |
| Velikost | 1512.8 KB |
| Verifikováno | proběhl by sanity-check.ps1 ihned po extract + npm install |
