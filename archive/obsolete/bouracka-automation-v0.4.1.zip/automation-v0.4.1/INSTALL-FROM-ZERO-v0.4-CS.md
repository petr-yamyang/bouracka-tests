# Bouračka Test Suite — Instalace od nuly — v0.4 CS

> **Audience.** Druhý a další operátor (= "follower"). Nahrazuje
> `INSTALL-FROM-ZERO-v0.3-CS.md` na základě **reálné instalace na
> ThinkPadu 2026-05-06**, která odhalila několik nečekaných gotchas.
>
> **Cíl.** Po dokončení této příručky:
> - máte funkční Python + Node + (volitelně) JRE pro PlantUML
> - umíte spustit Bouračka tooling (Excel validátor, render scripty)
> - umíte spustit Playwright bring-up smoke proti DEMO Bouračce
> - máte jasný mental model kdy použít `py` vs `python` (TLDR: vždy `py`)
>
> **Doba instalace:** 25 minut čistého času (z toho ~15 minut čekání
> na stahování Pythonu a Chromia).

---

## §0. Klíčové pravidlo (přečtěte PŘED instalací)

> ⚠ **Na Windows **VŽDY** používejte `py` místo `python`,
>    a `py -m pip` místo `pip`.**
>
> Důvod: Windows 10/11 má v `%LOCALAPPDATA%\Microsoft\WindowsApps\`
> stub binárky `python.exe` + `python3.exe`, které redirect-ují
> uživatele do Microsoft Store. Tyto stuby jsou na PATH **PŘED**
> winget Pythonem. `py.exe` (Python Launcher for Windows) na rozdíl
> od `python.exe` není zastíněný a funguje správně okamžitě po `winget install`.
>
> Stejný problém má `pip.exe` (umístěn v `Python312\Scripts\` který
> není na PATH). Proto `py -m pip ...`, ne `pip ...`.

Příklady místo `python` / `pip`:

```pwsh
# Místo: python --version
py --version

# Místo: pip install openpyxl --break-system-packages
py -m pip install openpyxl --break-system-packages

# Místo: python tools\validate_workbook.py
py tools\validate_workbook.py

# Místo: pip list
py -m pip list
```

Další gotcha: `py` (bez argumentů) zapíná **REPL** (`>>>` prompt).
Pokud chcete jen ověřit verzi, používejte `py --version`. Pokud
omylem skončíte v REPL, ven: `exit()` nebo `Ctrl+Z` + `Enter`.

---

## §1. Předpoklady

| Položka | Verze | Poznámka |
|---------|-------|----------|
| Windows | 10 / 11 | testováno na 11 24H2 |
| Administrátor | dočasně | pro `winget` instalaci runtime balíčků |
| Disk free | ≥ 5 GB | Playwright Chromium ~150 MB + ostatní |
| Internet | běžný | povolené domény: `*.npmjs.com`, `pypi.org`, `github.com`, `*.python.org`, `playwright.download.prss.microsoft.com`, `cdn.playwright.dev` |

## §2. Preflight — winget source reset

**Empirická zkušenost:** první `winget install Python.Python.3.12`
často selže s chybou *"Failed when opening source(s); try the
'source reset' command if the problem persists"*. Reset napravuje:

```pwsh
# Otevřete PowerShell jako administrátor
winget source reset --force

# Verifikace
winget source list
# Měli byste vidět: msstore + winget
```

Tento krok přeskočte **jen pokud** jste v posledních 24 h winget úspěšně
používali pro jakýkoliv jiný balíček.

## §2b. Preflight — PowerShell ExecutionPolicy

**Empirická zkušenost:** Windows defaultně má `ExecutionPolicy: Restricted`,
což blokuje VŠECHNY `.ps1` skripty. Bouračka workflow potřebuje spustit:
- `npm.ps1` (`npm` na Windows je PS skript) — typicky první co selže
- vlastní `scripts\*.ps1` v repu (run-bring-up-smoke, sanity-check atd.)

**Fix — jednou pro user-level (žádný admin):**

```pwsh
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
# Při potvrzení: Y nebo A
```

**Verifikace:**

```pwsh
Get-ExecutionPolicy -List
# Očekávaný výstup pro CurrentUser: RemoteSigned
```

**Co `RemoteSigned` znamená:**
- Lokální skripty (bouracka-tests, `npm.ps1` z lokální instalace) → běží volně
- Stažené skripty z internetu → vyžadují signaturu od důvěryhodného vydavatele
- **Bezpečný default** pro vývojářské stanice; doporučení Microsoftu

Tento krok lze přeskočit **jen pokud** ručně už máte nastavený
`RemoteSigned` (nebo méně restriktivní) — ověřte přes `Get-ExecutionPolicy`.

## §3. Runtime instalace (admin window — ~15 minut)

### §3.1 Python 3.12

```pwsh
# Stále v admin PowerShell
winget install Python.Python.3.12
# Pokud se objeví "Do you agree to all the source agreements terms? [Y] Yes [N] No:" → Y
# Stahování ~25 MB; instalace ~30 s
```

**Po skončení instalace:**

```pwsh
# OTEVŘETE NOVÝ PowerShell (jakýkoliv user-level, ne admin)
py --version
# Očekávaný výstup: Python 3.12.10
```

> ⚠ Pokud `py --version` říká *"Python was not found..."* → buď
> winget instalace skutečně selhala (zkuste znovu od §3.1), nebo
> máte korporátní AppLocker policy. V tom případě Fix 2 z §13.1
> v0.3 příručky.

### §3.2 Pip (upgrade na nejnovější verzi)

Winget Python přichází s pip 25.x; doporučujeme aktualizovat:

```pwsh
py -m pip install --upgrade pip
# "Successfully installed pip-26.x" — varování o PATH si nevšímejte
```

### §3.3 Závislosti pro Bouračka tooling

```pwsh
py -m pip install openpyxl --break-system-packages
# "Successfully installed openpyxl-3.x.x"

# Ověřit:
py -c "import openpyxl; print('openpyxl', openpyxl.__version__)"
# Očekávaný výstup: openpyxl 3.x.x
```

Flag `--break-system-packages` je potřeba na Pythonu 3.11+ na
"externally-managed" environment (PEP 668). Bezpečné — winget Python
není systémový.

### §3.4 Node.js 20 LTS

```pwsh
# Admin PowerShell
winget install OpenJS.NodeJS.LTS
```

⚠ **Po instalaci `node` NEbude fungovat v současném PowerShellu**
(PATH snapshot, viz §3.7 níže). **Otevřete nový PowerShell** nebo
refresh PATH:

```pwsh
# Nový PowerShell (preferované):
node --version          # v20.x.x  nebo  v24.x.x
npm --version           # 10.x.x  nebo  11.x.x

# NEBO inline refresh aktuální session:
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
node --version
```

### §3.5 (Volitelné) Java JRE 21 pro PlantUML

Pokud budete renderovat UML diagramy do PNG/SVG:

```pwsh
winget install Microsoft.OpenJDK.21
```

⚠ Stejný PATH snapshot problém jako u Node.js — **nový PowerShell** nebo refresh:

```pwsh
# Nový PowerShell (preferované) NEBO:
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")

# Pak:
java --version          # openjdk 21.x

# Stáhnout PlantUML jar (do user folderu, žádný admin)
$tools = "$env:USERPROFILE\tools"
New-Item -ItemType Directory -Force -Path $tools | Out-Null
Invoke-WebRequest 'https://github.com/plantuml/plantuml/releases/download/v1.2024.7/plantuml-1.2024.7.jar' -OutFile "$tools\plantuml.jar"

# Test render
java -jar "$tools\plantuml.jar" -version
```

### §3.6 (Volitelné) Mockoon CLI pro N8 SMS Gateway mock

```pwsh
npm install -g @mockoon/cli
mockoon-cli --version
```

### §3.7 Klíčové pravidlo — PATH snapshot v PowerShell

**Empirická zkušenost:** každý `winget install <něco-co-přidává-bin-na-PATH>`
zapíše PATH do **systémového** environment (HKLM), ale **současná
PowerShell session** má PATH nasnímaný od svého spuštění a NEVÍ o
změně. Proto:

| `winget install` | Jak ovlivní | Co dělat |
|------------------|-------------|----------|
| `Python.Python.3.12` | nepřidává `python.exe` na PATH před stub; ale `py.exe` je vždy na PATH | použijte `py` (§0) |
| `OpenJS.NodeJS.LTS` | přidává `node.exe`, `npm.cmd` na systém PATH | nový shell NEBO refresh |
| `Microsoft.OpenJDK.21` | přidává `java.exe` na systém PATH | nový shell NEBO refresh |
| `Microsoft.PowerToys` | přidává PowerToys na PATH | nový shell NEBO refresh |
| (cokoliv s bin/PATH) | obecně | nový shell NEBO refresh |

**Refresh inline (bez nového shell):**

```pwsh
$env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User")
```

**Sanity rule:** po každé `winget install` co může něco přidat na PATH,
buď otevřete nový PowerShell, nebo proveďte tento refresh. Je to
jednořádkové; přidejte si do PowerShell profilu jako alias:

```pwsh
notepad $PROFILE
# Přidejte funkci:
function Refresh-Path { $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path","User") }
```

Po reload profilu (`. $PROFILE`) můžete jen psát `Refresh-Path` po každé winget instalaci.

## §4. Rozbalení distribuce

```pwsh
# Vyberte cílový adresář
$dir = "C:\bouracka-tests"
mkdir $dir -Force

# Rozbalte všechny dodané ZIPy do $dir
# Doporučené nástroje: PowerShell `Expand-Archive`, 7-Zip, Windows Explorer

cd $dir
ls
# Měli byste vidět: BOURACKA-TESTPLAN-v0.4.x.xlsx, package.json, _install\, _specs\,
# fixtures\, mockoon\, playwright\, recon\, scripts\, tools\, ...
```

**Verifikace SHA256 přílohy** (paranoidní, ale doporučené):

```pwsh
Get-FileHash bouracka-analytical-v0.4.0.zip -Algorithm SHA256
# Porovnat s hodnotou v MANIFEST-CS.md
```

## §5. Playwright + Chromium

```pwsh
cd $dir
npm install                       # ~ 60 s (~ 200 MB)
npx playwright install chromium   # ~ 3 min (~ 150 MB stahování)
npx playwright --version          # Version 1.x.x
```

> ⚠ **Pokud `npx playwright install` selže** s `Failed to download Chromium`,
> blokuje vás SecOps proxy. Otevřete ticket na allowlist těchto domén:
> `playwright.download.prss.microsoft.com`, `cdn.playwright.dev`.

## §6. 30-sekundový sanity-check

```pwsh
cd $dir

# 1. Excel pipeline
py tools\check_priority_matrix.py BOURACKA-TESTPLAN-v0.4.0.xlsx
# Očekávaný výstup: [summary] N rows checked, 0 violations
# Očekávaný exit kód: 0

# 2. Playwright pipeline
npx playwright test playwright/tests/bring-up-smoke.spec.ts --project=chromium-mobile
# Očekávaný výstup: 1 test passed; HTML report v playwright-report\

# 3. PlantUML pipeline (pokud jste instalovali §3.5)
.\tools\render-uml.ps1 -FlowFolder recon\screenflows-live\flow-A1-main-tst-demo
# Očekávaný výstup: 3× "[OK] *.puml -> PNG + SVG" v uml\
```

Pokud projdou **všechny 3 testy**, instalace je zdravá. Pokud něco
selže, viz §10 troubleshoot.

## §7. První produktivní použití

### §7.1 Odeslat smoke test proti veřejné DEMO Bouračce

```pwsh
.\scripts\run-bring-up-smoke.ps1
# Spustí Playwright proti https://demo.bouracka.cz, mobile viewport
# 1 test passed = můžete začít psát další TC
```

### §7.2 Spustit intel-probes (obohatit fixtures živými daty)

```pwsh
# Read-only probe — bezpečné, žádné zápisy do SUT
npx playwright test playwright/tests/intel-probes/01-enumeration-dump.spec.ts

# Výstup: fixtures/intel-2026-MM-DD/{enums,bundles,traces}/*.json
```

### §7.3 Otevřít master Excel s branch-aware filterem

1. Otevřete `BOURACKA-TESTPLAN-v0.4.0.xlsx` v Excelu 2016+
2. Přejděte na list `00e_BranchView` — vidíte counts per branch
3. Přejděte na `02_TestCases` — sloupce `applies_to_demo` + `applies_to_prod`
   barevně odlišené
4. Klikněte na šipku AutoFilter v záhlaví `applies_to_demo` →
   zaškrtněte JEN `TRUE` → vidíte jen DEMO-relevantní TC

### §7.4 Render branched analytického dokumentu

```pwsh
py tools\render_branch_doc.py recon\ANALYTICAL-DOC-MASTER-v0.4.md --branch demo
# Vytvoří: recon\ANALYTICAL-DOC-MASTER-v0.4-DEMO.md (jen DEMO sekce + společné)

py tools\render_branch_doc.py recon\ANALYTICAL-DOC-MASTER-v0.4.md --branch prod
# Vytvoří: recon\ANALYTICAL-DOC-MASTER-v0.4-PROD.md
```

## §8. Příprava UTF-8 BOM pro PowerShell skripty (pokud nepoužíváte PS 7)

PowerShell 5.1 čte BOM-less UTF-8 jako Windows-1252 — láme české znaky a
em-dashe. Skripty v balíčku jsou s BOM, ale po editaci v některých
editorech se BOM ztratí. Verifikace:

```pwsh
$bomCheck = [System.IO.File]::ReadAllBytes("scripts\run-bring-up-smoke.ps1")[0..2]
if ($bomCheck[0] -eq 0xEF -and $bomCheck[1] -eq 0xBB -and $bomCheck[2] -eq 0xBF) {
    "[ok] BOM ok"
} else {
    "[fail] BOM chybí — opravit:"
    "  `$content = [System.IO.File]::ReadAllText('scripts\run-bring-up-smoke.ps1')"
    "  [System.IO.File]::WriteAllText('scripts\run-bring-up-smoke.ps1', `$content, [System.Text.UTF8Encoding]::new(`$true))"
}
```

> Pokud máte k dispozici PowerShell 7+ (`pwsh.exe`), BOM problém řeší automaticky — preferujte ho.

## §9. Diagnostické skripty

| Skript | Co dělá | Spustit kdy |
|--------|---------|-------------|
| `scripts\setup-from-zero.ps1` | one-shot Profile-C install (volá §3 + §5) | poprvé na čistém stroji |
| `scripts\validate-install.ps1` | 14 zdravotních kontrol prostředí | před každým během |
| `scripts\run-bring-up-smoke.ps1` | smoke test proti DEMO | po instalaci |
| `scripts\run-all.ps1` | Playwright + Cypress + TestCafe (po instalaci) | full regression |
| `tools\test-console.ps1 status` | reportuje, jaké frameworky jsou runnable | diagnostika |

## §10. Co dělat, když něco selže — troubleshoot

| Symptom | Příčina | Řešení |
|---------|---------|---------|
| `winget install`: "Failed when opening source(s)" | winget source registr poškozený | `winget source reset --force` (§2) |
| `python --version`: "not found" po úspěšné winget instalaci | MS Sto