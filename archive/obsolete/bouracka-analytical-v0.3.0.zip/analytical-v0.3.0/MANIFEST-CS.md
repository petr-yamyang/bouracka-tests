# Manifest — Analytický balíček v0.3.0 — 2026-05-06

> Kompletní seznam souborů s SHA256 kontrolními součty pro audit a integritu.

## §1. Soubory (analytical-v0.3.0)

| Soubor | Velikost (B) | SHA256 |
|--------|--------------|--------|
| `00_README-CS.md` | 7089 | `c1eb567a765762b50b0793b12701790203e80d789017167ba253f589a209b4d6` |
| `06_DELTA-DEMO-vs-PROD-CS.md` | 4310 | `078534e9ac4dab2900075300b1266c4ee4fddadf484469718f023b5beda32e53` |
| `BOURACKA-TESTPLAN-v0.3.xlsx` | 89455 | `f84d260ab104876fd24dcee26580ba3a8a199bcf961ebbe1ac6960a48d1c1556` |
| `INSTALL-FROM-ZERO-v0.3-CS.md` | 9215 | `f29800fb5b80de07126972bcb5c06e700f18a3ec712462e30476a53c798558bf` |
| `fixtures/api-endpoints-live-2026-05-06.yaml` | 10133 | `fe8243fb5ce1201d0f783afe2db4dd5fb0c0345c916d8dca3610e36d512c65e6` |
| `fixtures/codelists-live-2026-05-06.yaml` | 14027 | `2845115cb69cc0f0b185bb187662f6d104c4ca9c81f3dabe4ace70ea616afbad` |
| `fixtures/live-copy-strings.yaml` | 10731 | `47b74ee8995b34813c52ae902b95f62619a11a0dc35bcdd79dda3b5919505b9a` |
| `recon/ANALYTICAL-DOC-INTELLIGENCE-v0.3.md` | 12558 | `e789b50a64598b70303c03fd8adbb5d8a9e3aea3f81f257451725dc544a1aece` |
| `recon/DELTA-DEMO-vs-PROD-v0.1.md` | 6624 | `4460bdd69c330bc7f1d656778dcde8f00360f2e95eebb5c40f4f98ed0982d828` |
| `recon/DEMO-PUBLIC-LIVE-2026-05-06.md` | 10239 | `1c561c43c125027e4d557b4fce5b10fcc29e33dfee553a800ee6937f2d45c672` |
| `recon/INT-006.md` | 1977 | `4fe8e2eb30193f72093bf789898795e320201d6962aa8dc23687af5917a33e35` |
| `recon/INT-007.md` | 2637 | `d7c21789b5f825bb8e27c9929a80ef0a2602aecd9ba570801d7be176db6642f7` |
| `recon/INT-008.md` | 3598 | `376838570b9562c6f014482d5b85a8a06a5f8bb36fbfa9bab31320d33366a7cb` |
| `recon/INT-009.md` | 3722 | `d53cd5fe896cb3bb9c4a89ceaad84c088f78a0c9b6ccceaf7667b3ff8602df70` |
| `recon/flow-A1-main-tst-demo.md` | 35303 | `f6a2866af6248ed36c25819417ede8ded9d43d25ede620db989633698aeff1f4` |
| `uml/activity.puml` | 5003 | `6e9def0c96878ddda2c50bd7e630db63d58215506e466c4d835540586ca95c1f` |
| `uml/sequence.puml` | 5445 | `d7b8e8dbf7c15dddee8c2bfec73cd2837a726e052741cdf9e08508e1fe114651` |
| `uml/use-case.puml` | 3634 | `53b07446b3e3efed73073107539037605a92b5ae37257b71dfcb06e314032c9b` |
| **TOTAL** | **235 700 B (≈230 KB)** | — |

## §2. Verifikace

PowerShell:

```pwsh
Get-FileHash <soubor> -Algorithm SHA256
```

Bash:

```bash
sha256sum <soubor>
```

## §3. Status

| Item | Hodnota |
|------|---------|
| Verze | v0.3.0 |
| Datum | 2026-05-06 |
| Vejde se do 1 e-mailu | ANO (≈230 KB) |
| Email-volume split | NE — vše do jednoho ZIPu |
