<#
.SYNOPSIS
  30-sekundový sanity check po instalaci — ověří 7 kritických komponent.

.DESCRIPTION
  Per CP-SUPIN-04 STEP 20. Spustit po dokončení INSTALL-FROM-ZERO-v0.4-CS.md
  jako last-mile verifikace. Reportuje ✓/✗ pro:
    1. py launcher (§0 mental model)
    2. py -m pip (place of bare pip)
    3. openpyxl import
    4. node + npm
    5. npx playwright
    6. workbook + check_priority_matrix.py
    7. Excel master přítomný (BOURACKA-TESTPLAN-v0.4.0.xlsx)

  Exit kód: počet selhání (0 = vše OK).

.EXAMPLE
  .\scripts\sanity-check.ps1
#>
$ErrorActionPreference = 'Continue'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$ok = 0; $fail = 0

function Check {
    param([string]$Name, [scriptblock]$Test)
    $r = & $Test
    if ($r) {
        Write-Host "  ✓ $Name" -ForegroundColor Green
        $script:ok++
    } else {
        Write-Host "  ✗ $Name" -ForegroundColor Red
        $script:fail++
    }
}

Write-Host ""
Write-Host "=== Bouračka sanity-check ===" -ForegroundColor Cyan
Write-Host ""

# 1. py launcher
Check "py launcher works" {
    $v = & py --version 2>&1
    $LASTEXITCODE -eq 0 -and $v -match 'Python 3\.'
}

# 2. py -m pip
Check "py -m pip works" {
    & py -m pip --version *> $null
    $LASTEXITCODE -eq 0
}

# 3. openpyxl import
Check "openpyxl importovatelné" {
    & py -c "import openpyxl; assert openpyxl.__version__ >= '3.0'" *> $null
    $LASTEXITCODE -eq 0
}

# 4. Node + npm
Check "Node.js + npm na PATH" {
    $nodeOk = (Get-Command node -ErrorAction SilentlyContinue) -ne $null
    $npmOk = (Get-Command npm -ErrorAction SilentlyContinue) -ne $null
    $nodeOk -and $npmOk
}

# 5. npx playwright
Check "Playwright nainstalovaný" {
    if (-not (Test-Path "node_modules\@playwright\test")) { return $false }
    & npx playwright --version *> $null
    $LASTEXITCODE -eq 0
}

# 6. Excel master přítomný
$wb = "BOURACKA-TESTPLAN-v0.4.0.xlsx"
Check "Excel master $wb" {
    Test-Path $wb
}

# 7. Priority matrix validátor
Check "check_priority_matrix.py = 0 violations" {
    if (-not (Test-Path $wb)) { return $false }
    & py "tools\check_priority_matrix.py" $wb *> $null
    $LASTEXITCODE -eq 0
}

Write-Host ""
Write-Host "Result: $ok passed, $fail failed" -ForegroundColor $(if ($fail -eq 0) { 'Green' } else { 'Yellow' })
Write-Host ""

if ($fail -gt 0) {
    Write-Host "Co dál:" -ForegroundColor Yellow
    Write-Host "  - Pokud chybí py / openpyxl / Node: viz INSTALL-FROM-ZERO-v0.4-CS.md §3" -ForegroundColor Gray
    Write-Host "  - Pokud chybí Playwright: cd `$root && npm install && npx playwright install chromium" -ForegroundColor Gray
    Write-Host "  - Pokud chybí Excel master: rozbalte bouracka-analytical-v0.4.0.zip" -ForegroundColor Gray
    Write-Host "  - Plný troubleshoot: INSTALL-FROM-ZERO-v0.4-CS.md §10" -ForegroundColor Gray
}
exit $fail
