$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot; Set-Location $root
$env:BOURACKA_BASE = "https://tst.bouracka.cz"
Write-Host "[run-on-prod-tst] target=$($env:BOURACKA_BASE)" -ForegroundColor Cyan
.\scripts\prereq-check.ps1
if ($LASTEXITCODE -ne 0) { Write-Host "[abort] preflight failed" -ForegroundColor Red; exit 1 }
npx playwright test --project=single-env
