$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot; Set-Location $root
if ($env:I_HAVE_READ_PROD_PREREQUISITES -notmatch "^yes-\d{4}-\d{2}-\d{2}$") {
    Write-Host "[FAIL] PROD run blocked. Read README §5, then set:" -ForegroundColor Red
    Write-Host '  $env:I_HAVE_READ_PROD_PREREQUISITES = "yes-' + (Get-Date -Format yyyy-MM-dd) + '"' -ForegroundColor Yellow
    exit 1
}
$env:BOURACKA_BASE = "https://bouracka.cz"
Write-Host "[run-on-prod] target=$($env:BOURACKA_BASE)" -ForegroundColor Magenta
npx playwright test --project=single-env
