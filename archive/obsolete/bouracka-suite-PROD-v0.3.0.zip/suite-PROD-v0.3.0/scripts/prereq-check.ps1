<#
.SYNOPSIS
  Preflight kontrola — co je / není připravené pro PROD suite.

.DESCRIPTION
  Reportuje 8 položek:
   1. Node + npm + Playwright nainstalované
   2. tst.bouracka.cz dosažitelný
   3. bouracka.cz dosažitelný
   4. N8_SANDBOX_URL nastavena
   5. AISPOV_TOKEN nastavena
   6. fixtures/tester-contacts.yaml existuje (NE template)
   7. I_HAVE_READ_PROD_PREREQUISITES nastavena
   8. Mockoon CLI dostupné (pro adapter mode)
#>
$ErrorActionPreference = 'Continue'
$ok = 0
$fail = 0

function Check-Item {
    param([string]$Name, [scriptblock]$Test)
    try {
        $r = & $Test
        if ($r) {
            Write-Host "  ✓ $Name" -ForegroundColor Green
            $script:ok++
        } else {
            Write-Host "  ✗ $Name" -ForegroundColor Red
            $script:fail++
        }
    } catch {
        Write-Host "  ✗ $Name  ($_)" -ForegroundColor Red
        $script:fail++
    }
}

Write-Host ""
Write-Host "=== PROD suite — preflight ===" -ForegroundColor Cyan
Write-Host ""

Check-Item "Node.js installed"            { (Get-Command node -ErrorAction SilentlyContinue) -ne $null }
Check-Item "Playwright installed"          { Test-Path "node_modules\@playwright\test" }
Check-Item "tst.bouracka.cz reachable (VPN)" {
    (Test-NetConnection tst.bouracka.cz -Port 443 -WarningAction SilentlyContinue).TcpTestSucceeded
}
Check-Item "bouracka.cz reachable"         {
    (Test-NetConnection bouracka.cz -Port 443 -WarningAction SilentlyContinue).TcpTestSucceeded
}
Check-Item "N8_SANDBOX_URL env var set"    { -not [string]::IsNullOrEmpty($env:N8_SANDBOX_URL) }
Check-Item "AISPOV_TOKEN env var set"      { -not [string]::IsNullOrEmpty($env:AISPOV_TOKEN) }
Check-Item "tester-contacts.yaml present (not template)" {
    Test-Path "fixtures\tester-contacts.yaml"
}
Check-Item "I_HAVE_READ_PROD_PREREQUISITES set" {
    $env:I_HAVE_READ_PROD_PREREQUISITES -match "^yes-\d{4}-\d{2}-\d{2}$"
}
Check-Item "Mockoon CLI installed"         { (Get-Command mockoon-cli -ErrorAction SilentlyContinue) -ne $null }

Write-Host ""
Write-Host "Result: $ok passed, $fail failed" -ForegroundColor $(if ($fail -eq 0) { 'Green' } else { 'Yellow' })
Write-Host ""
if ($fail -gt 0) {
    Write-Host "Co dál:" -ForegroundColor Yellow
    Write-Host "  - Pokud chybí Node/Playwright: viz INSTALL-FROM-ZERO-v0.3-CS.md §5" -ForegroundColor Gray
    Write-Host "  - Pokud chybí síťový přístup: zapnete VPN ČKP nebo požádejte SecOps" -ForegroundColor Gray
    Write-Host "  - Pokud chybí N8/AISPOV: požádejte SUPIN OPS / ČKP IT (viz docs/PROD-PREREQUISITES-CS.md)" -ForegroundColor Gray
    Write-Host "  - Pokud chybí tester-contacts.yaml: zkopírujte z .template a vyplňte" -ForegroundColor Gray
}
exit $fail
