$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot; Set-Location $root
Write-Host "[run-with-mockoon] starting Mockoon on :3001 (Ctrl+C to stop)" -ForegroundColor Cyan
mockoon-cli start --data mockoon/n8-sms-gateway.json --port 3001
