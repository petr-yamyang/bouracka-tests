# Bouračka — Test Suite "PROD" — v0.3.0

> **Co je uvnitř.** Test sada pokrývající **PRODUKČNÍ Bouračku
> (`bouracka.cz`) a její firewall-gated test variantu (`tst.bouracka.cz`)**.
> Suite je parametrizovaná stejně jako DEMO suite — jeden a tentýž
> kód běží proti oběma prostředím.
>
> **DŮLEŽITÉ — TATO SADA JE AKTUÁLNĚ BLOKOVANÁ.** Většina TC vyžaduje:
> - **N8 SMS Gateway sandbox / skip-flag** (pro reálné OTP testy bez doručování SMS)
> - **AISPOV (CRR / CRV / ROB) read-only přístup** (pro reálné registrové dotazy)
> - **zenID test-keys** (pro OCR z OP / ŘP)
> - **VPN přístup** k `tst.bouracka.cz` (firewall ČKP)
>
> Bez nich se každý TC v této sadě **automaticky přeskočí** s důvodem.
> Smysl je: jakmile SUPIN/ČKP doručí přístupy, suite **se okamžitě rozjede**
> beze změny kódu.

---

## §1. Cílová prostředí

| Prostředí | URL | Síťový přístup | Použít kdy |
|-----------|-----|----------------|------------|
| `prod` | `https://bouracka.cz` | veřejné (rozcestník), ale chráněné integrace | po dodání N8 sandbox |
| `prod-tst` | `https://tst.bouracka.cz` | za firewallem ČKP | preprod validace; jediné prostředí kde lze bezpečně exercise reálné integrace |

**Bezpečnost:** TCs proti `prod` jsou navrženy tak, aby NEROZESLALY SMS na
neznámá čísla a NEZAPSALY data do reálných registrů. Operátor MUSÍ
přečíst §5 (Konfidenciální poznámky) před spuštěním.

## §2. Co tento balíček obsahuje

```
suite-PROD-v0.3.0/
├── README-PROD-CS.md                ← tento soubor
├── package.json
├── playwright.config.ts             ← projects: prod + prod-tst
├── tsconfig.json
├── tests/
│   ├── 01-smoke-prod.spec.ts        ← rozcestník existuje (i když je veřejný)
│   ├── 02-no-demo-banner.spec.ts    ← TC-CP-NEW-C inverze (PROD nesmí mít DEMO baner)
│   ├── 03-prod-otp-rejects.spec.ts  ← TC-CP-NEW-P (PROD odmítá libovolný OTP) — gated
│   ├── 04-real-sms-gate.spec.ts     ← TC-CP-005-PROD (skutečný SMS přes N8) — gated
│   ├── 05-aispov-driver-load.spec.ts ← TC-CP-NEW-T (real CRR) — gated
│   ├── 06-real-email-dispatch.spec.ts ← TC-CP-022 (final email) — gated
│   └── 07-rate-limiting.spec.ts     ← TC-CP-NEW-N (POST /reports rate-limit) — gated
├── fixtures/
│   ├── prod-config.yaml             ← env-aware fixture overrides
│   └── tester-contacts.yaml.template ← TŘÍDA: PII; vyplňte ručně před spuštěním
├── mockoon/
│   └── n8-sms-gateway.json          ← adapter mode: routuje N8 calls do mock serveru
├── scripts/
│   ├── run-on-prod.ps1
│   ├── run-on-prod-tst.ps1
│   ├── run-with-mockoon.ps1         ← spustí Mockoon + testy proti localhost N8 mock
│   └── prereq-check.ps1             ← ověří env vars + síť + N8 sandbox dostupnost
├── docs/
│   └── PROD-PREREQUISITES-CS.md     ← detailní seznam co musí SUPIN/ČKP dodat
└── MANIFEST-CS.md
```

## §3. Mapa TC ↔ env_constraints

Tato sada zahrnuje TC s `env_constraints ∈ {prod-only, both-with-adapter}`:

**`prod-only` (potřebují reálné PROD prostředí):**
- TC-CP-005-PROD (skutečný SMS přes N8 — operátor obdrží reálnou SMS)
- TC-CP-022 (skutečný e-mail rozeslání)
- TC-CP-NEW-J (DEMO hint **nesmí být** přítomen)
- TC-CP-NEW-P (PROD **odmítá** libovolný 4-digit OTP)
- TC-CP-NEW-T-PROD (skutečný AISPOV CRR dotaz)

**`both-with-adapter` (běží na obou s adaptérem mock/real):**
- TC-CP-005 (s Mockoon mock = předvídatelný "1234" OTP)
- TC-CP-006 (verification flow mock-mode)
- TC-CP-008 (driver-data load adapter)
- TC-CP-NEW-N (rate-limit adapter)

## §4. Předpoklady (= co potřebujeme od SUPIN/ČKP)

Detailní rozpis v `docs/PROD-PREREQUISITES-CS.md`. Stručný seznam:

| # | Co potřebujeme | Status | Odpovědný |
|---|----------------|--------|-----------|
| 1 | N8 SMS Gateway sandbox URL + API key (test-mode) | OQ-CP-27 — pending | SUPIN OPS |
| 2 | NEBO: skip-flag header pro PROD `?skip-sms=true` během testů | TBD | SUPIN backend |
| 3 | AISPOV read-only přístup (CRR/CRV/ROB) | TBD | ČKP IT |
| 4 | zenID OCR test-keys (sandbox) | OQ-CP-XX — pending | ČKP IT |
| 5 | Allowlist `tst.bouracka.cz` ve firewallu pro tester laptop | TBD | SecOps |
| 6 | Tester telefonní číslo pro reálné SMS testy (verifikované) | NA — operátor | operátor |
| 7 | Tester e-mailový alias `bouracka-tester@…` | NA — operátor | operátor |

Bez bodů 1-5 zůstávají TC v této sadě **přeskakované** (skip s důvodem).

## §5. Konfidenciální poznámky před spuštěním

⚠ **Před spuštěním této sady proti `prod` (NE `prod-tst`):**

1. **Reálné SMS** — TC-CP-005-PROD pošle skutečnou SMS na číslo
   uvedené ve `fixtures/tester-contacts.yaml`. Toto číslo musí
   patřit operátorovi nebo testovacímu zařízení v jeho vlastnictví.
   **Nikdy neposílejte testovací SMS na neznámá čísla.**

2. **Reálné e-maily** — TC-CP-022 dispatchuje e-mail. Použijte alias
   `bouracka-tester@…` v `tester-contacts.yaml`, ne osobní e-mail.

3. **Reálné registry** — TC-CP-NEW-T-PROD dotazuje AISPOV CRR
   na **synthetické** SPZ, OP a ŘP. Operátor MUSÍ použít buď
   přidělené testovací identity z ČKP, NEBO synthetické hodnoty
   nepatřící žádné reálné osobě / vozidlu.

4. **Po každém PROD běhu** — manuálně zkontrolujte, že vytvořené
   reporty na `bouracka.cz` byly purgnuté podle UI copy
   "Pokud nedojde k závěrečnému oboustrannému potvrzení, všechna
   zadaná data včetně kontaktů budou smazána bez uložení."

5. **Pro CI / unattended** — používejte JEN `prod-tst` (firewall-gated).
   `prod` testování je manual gate-keeper režim.

## §6. Spuštění — krok za krokem

### §6.1 Preflight kontrola

```pwsh
.\scripts\prereq-check.ps1
```

Reportuje:
- ✓/✗ Node + Playwright nainstalované
- ✓/✗ Síťová dostupnost `tst.bouracka.cz` (vyžaduje VPN)
- ✓/✗ `N8_SANDBOX_URL` env var nastavena
- ✓/✗ `AISPOV_TOKEN` env var nastavena
- ✓/✗ `fixtures/tester-contacts.yaml` vyplněno (ne template)

### §6.2 Spuštění proti `tst.bouracka.cz` (preferovaný režim)

```pwsh
$env:BOURACKA_BASE = "https://tst.bouracka.cz"
.\scripts\run-on-prod-tst.ps1
```

### §6.3 Spuštění s Mockoon adaptérem

```pwsh
# V prvním terminálu — nastartovat mock
.\scripts\run-with-mockoon.ps1
# (drží mock server na localhost:3001)

# V druhém terminálu — spustit testy
$env:N8_BASE = "http://localhost:3001"
$env:BOURACKA_BASE = "https://demo.bouracka.cz"  # OR prod-tst
npx playwright test --project=prod-mockoon
```

### §6.4 Spuštění proti `bouracka.cz` (manual gate-keeper režim)

```pwsh
# DŮKLADNĚ si přečtěte §5 nahoře.
$env:BOURACKA_BASE = "https://bouracka.cz"
$env:I_HAVE_READ_PROD_PREREQUISITES = "yes-2026-05-06"
.\scripts\run-on-prod.ps1
```

Skript odmítne spustit, pokud `I_HAVE_READ_PROD_PREREQUISITES` není
nastavena na dnešní datum.

## §7. Velikost a e-mailové doručení

| Položka | Hodnota |
|---------|---------|
| ZIP velikost | < 100 KB (bez Mockoon profilu < 50 KB) |
| Doba scanu | typicky 10-30 s |
| Distribuce | 1× e-mail; nezávislé od DEMO suite |
| Konfidenciální obsah | NE (fixtures/tester-contacts.yaml NENÍ v balíčku — operátor musí vyplnit ručně z template) |

## §8. Co dělat po prvním úspěšném běhu (až přijdou přístupy)

1. Otevřete `playwright-report/index.html`.
2. Stejné Δ chování jako u DEMO suite — pokud TC selže na `prod-tst` ale
   prošel na `prod`, je to potenciální config drift.
3. Po stabilní pass-rate doplnit do CI (Jenkins / GitHub Actions /
   Azure DevOps) — viz CP-SUPIN-05 pipeline koncept.

## §9. Status

| Item | Hodnota |
|------|---------|
| Suite | PROD-v0.3.0 |
| Pokrytí | bouracka.cz + tst.bouracka.cz |
| Počet TC | ~12 (5 prod-only + 4 both-with-adapter + 3 inverze DEMO) |
| Odvislost | N8 sandbox + AISPOV + zenID test-keys + VPN |
| Velikost ZIP | < 100 KB |
| Aktuální stav | **scaffolding (testy gated; jakmile přístupy přijdou, rozjede se)** |
| Datum | 2026-05-06 |
