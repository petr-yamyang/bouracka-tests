/**
 * 01-smoke-prod.spec.ts
 *
 * Same shape as DEMO smoke; verifies PROD/PROD-tst rozcestník is reachable
 * and renders the same structure as DEMO (since same JS bundle).
 *
 * NOT GATED — runs on any PROD twin, no creds needed.
 */
import { test, expect } from '@playwright/test';

test('SMOKE-PROD-01 — Rozcestník loads on PROD twin', async ({ page }) => {
  await page.goto('/formular/');
  await expect(page).toHaveTitle(/Bouračka/i);
  await expect(page.getByRole('button', { name: /Vyplnit záznam/i }).first()).toBeVisible();
});

test('TC-CP-NEW-J — DEMO banner MUST be absent on PROD', async ({ page }) => {
  await page.goto('/formular/');
  const demoBanner = page.getByText('Nacházíte se v DEMO VERZI aplikace.');
  await expect(demoBanner).toHaveCount(0);
});

test('TC-CP-NEW-J2 — Phase 1 DEMO hint MUST be absent on PROD', async ({ page }) => {
  // Reaches Phase 1 then asserts hint absent
  await page.goto('/formular/');
  await page.getByRole('button', { name: /Vyplnit záznam/i }).first().click();
  await page.getByRole('button', { name: 'Rozumím' }).click();
  await expect(page).toHaveURL(/\/verification/);
  const demoHint = page.getByText(/Demoverze žádné SMS neodesílá/);
  await expect(demoHint).toHaveCount(0);
});
