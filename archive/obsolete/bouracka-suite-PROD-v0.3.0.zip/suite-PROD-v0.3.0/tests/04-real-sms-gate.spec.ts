/**
 * 04-real-sms-gate.spec.ts
 *
 * TC-CP-005-PROD — Real SMS dispatch via N8 SMS Gateway (PROD-only)
 * TC-CP-NEW-P  — PROD rejects arbitrary 4-digit OTP
 *
 * GATED on env vars:
 *   - N8_SANDBOX_URL  (or N8_SKIP_FLAG)
 *   - TESTER_PHONE_E164  (e.g. +420608000099)
 *
 * Without them, tests skip with reason.
 */
import { test, expect } from '@playwright/test';

const N8_SANDBOX = process.env.N8_SANDBOX_URL ?? '';
const TESTER_PHONE = process.env.TESTER_PHONE_E164 ?? '';
const SAFE_TO_SEND_REAL_SMS = process.env.I_HAVE_READ_PROD_PREREQUISITES?.startsWith('yes-');

test.beforeEach(async () => {
  test.skip(!N8_SANDBOX || !TESTER_PHONE,
    'GATED — set N8_SANDBOX_URL + TESTER_PHONE_E164 to run');
  test.skip(!SAFE_TO_SEND_REAL_SMS,
    'GATED — set I_HAVE_READ_PROD_PREREQUISITES=yes-YYYY-MM-DD after reading README §5');
});

test('TC-CP-005-PROD — N8 dispatches a real SMS, OTP arrives, verify succeeds', async ({ page, request }) => {
  // Drive to verification
  await page.goto('/formular/');
  await page.getByRole('button', { name: /Vyplnit záznam/i }).first().click();
  await page.getByRole('button', { name: 'Rozumím' }).click();
  await expect(page).toHaveURL(/\/verification/);
  // Fill tester phone, submit
  const phoneDigits = TESTER_PHONE.replace(/^\+420/, '');
  await page.locator('input[type="tel"]').first().fill(phoneDigits);
  await page.getByRole('checkbox').first().check();
  // Watch for sendCodeToVerify response
  const sendResp = page.waitForResponse(
    (r) => r.url().includes('sendCodeToVerify') && r.request().method() === 'POST',
    { timeout: 15_000 },
  );
  await page.getByRole('button', { name: 'Odeslat kód' }).click();
  const sent = await sendResp;
  expect(sent.status()).toBe(200);
  // Poll N8 sandbox for the dispatched OTP
  const otp = await pollSandboxForOtp(request, TESTER_PHONE, 30_000);
  expect(otp).toMatch(/^\d{4}$/);
  // Type the OTP digits and submit
  await typeOtp(page, otp);
  const verifyResp = page.waitForResponse(
    (r) => r.url().includes('/verify') && r.request().method() === 'POST',
    { timeout: 15_000 },
  );
  await page.getByRole('button', { name: 'Ověřit' }).click();
  const verified = await verifyResp;
  expect(verified.status()).toBe(200);
});

test('TC-CP-NEW-P — PROD rejects arbitrary 4-digit OTP (negative case)', async ({ page }) => {
  await page.goto('/formular/');
  await page.getByRole('button', { name: /Vyplnit záznam/i }).first().click();
  await page.getByRole('button', { name: 'Rozumím' }).click();
  await page.locator('input[type="tel"]').first().fill(TESTER_PHONE.replace(/^\+420/, ''));
  await page.getByRole('checkbox').first().check();
  await page.getByRole('button', { name: 'Odeslat kód' }).click();
  // Wait for OTP screen
  await expect(page.getByText('Zadejte ověřovací kód')).toBeVisible({ timeout: 10_000 });
  // Submit OBVIOUSLY-WRONG code (1111 — not the real dispatched OTP)
  await typeOtp(page, '1111');
  const verifyResp = page.waitForResponse(
    (r) => r.url().includes('/verify') && r.request().method() === 'POST',
    { timeout: 15_000 },
  );
  await page.getByRole('button', { name: 'Ověřit' }).click();
  const verified = await verifyResp;
  // PROD MUST return 4xx for wrong OTP
  expect(verified.status()).toBeGreaterThanOrEqual(400);
  expect(verified.status()).toBeLessThan(500);
});

async function typeOtp(page: any, code: string) {
  await page.evaluate((digits: string) => {
    const inputs = document.querySelectorAll('input[type="tel"]');
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')!.set!;
    for (let i = 0; i < Math.min(inputs.length, digits.length); i++) {
      const input = inputs[i] as HTMLInputElement;
      setter.call(input, digits[i]);
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }, code);
}

async function pollSandboxForOtp(request: any, phone: string, timeoutMs: number): Promise<string> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const r = await request.get(`${N8_SANDBOX}/messages?to=${encodeURIComponent(phone)}`);
    if (r.status() === 200) {
      const messages = await r.json();
      const latest = (messages as any[]).find((m) => /\b\d{4}\b/.test(m.body || ''));
      if (latest) {
        const m = (latest.body as string).match(/\b(\d{4})\b/);
        if (m) return m[1];
      }
    }
    await new Promise((res) => setTimeout(res, 2000));
  }
  throw new Error(`N8 sandbox timeout — no OTP for ${phone} in ${timeoutMs}ms`);
}
