/**
 * Playwright config — Suite "PROD" — covers bouracka.cz + tst.bouracka.cz
 *
 * Three project modes:
 *   - prod        : real PROD (gated; requires I_HAVE_READ_PROD_PREREQUISITES)
 *   - prod-tst    : firewall-gated (requires VPN)
 *   - prod-mockoon: PROD URL but N8 calls intercepted via Mockoon
 */
import { defineConfig, devices } from '@playwright/test';

const PROD     = process.env.BOURACKA_BASE_PROD     ?? 'https://bouracka.cz';
const PROD_TST = process.env.BOURACKA_BASE_PROD_TST ?? 'https://tst.bouracka.cz';
const SINGLE   = process.env.BOURACKA_BASE;

export default defineConfig({
  testDir: './tests',
  timeout: 90_000,                   // larger — real SMS round trips can be slow
  expect: { timeout: 15_000 },
  fullyParallel: false,              // be polite to PROD
  retries: process.env.CI ? 2 : 0,
  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['json', { outputFile: 'test-results/results.json' }],
  ],
  use: {
    baseURL: SINGLE ?? PROD_TST,     // default to safer prod-tst when single mode
    locale: 'cs-CZ',
    timezoneId: 'Europe/Prague',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'off',                    // PRIVACY: no video on PROD runs
  },
  projects: SINGLE
    ? [
        { name: 'single-env', use: { ...devices['iPhone 12'], baseURL: SINGLE } },
      ]
    : [
        { name: 'prod',         use: { ...devices['iPhone 12'], baseURL: PROD     } },
        { name: 'prod-tst',     use: { ...devices['iPhone 12'], baseURL: PROD_TST } },
        // Adapter mode — same target URL but N8 routed via Mockoon localhost
        { name: 'prod-mockoon', use: { ...devices['iPhone 12'], baseURL: PROD_TST } },
      ],
});
