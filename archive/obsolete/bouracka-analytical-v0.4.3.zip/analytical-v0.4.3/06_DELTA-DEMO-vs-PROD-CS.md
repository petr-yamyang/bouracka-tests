# Δ matice DEMO vs PROD — souhrn pro SUPIN

> Plná matice s 26 řádky, 8 z nich potvrzeno z živé analýzy 2026-05-06.
> Detail s TC-impact a confidence tagy: `recon/DELTA-DEMO-vs-PROD-v0.1.md`.

## §1. Integrační deltové vrstvy

| # | Integrace | DEMO | PROD | Confidence | TC vliv |
|---|-----------|------|------|------------|---------|
| Δ1 | N8 SMS Gateway | žádné SMS; libovolný 4místný OTP přijat | reálné SMS, reálný OTP | **confirmed** | TC-CP-005-DEMO + TC-CP-005-PROD |
| Δ2 | AISPOV ROB | sandbox / synthetic | reálná data občanů | expected | TC-CP-008/009/010 |
| Δ3 | AISPOV CRR | sandbox / synthetic | reálná data vozidel | expected | TC-CP-014/015 |
| Δ4 | AISPOV CRV | sandbox / synthetic | reálná data pojištění vozidel | expected | TC-CP-014/015 + partner-routing |
| Δ5 | ZID / zenID OCR | instruktážní video | reálné OCR z OP/ŘP přes zenID SDK | **confirmed** | TC-CP-007/013 |
| Δ6 | reCAPTCHA v3 | site-key zveřejněn (`6Lfbao4sAAA…`) | site-key TBC; vyšší práh skóre | unknown | smoke + abuse TC |
| Δ7 | Email dispatch | NIC nedoručeno (potvrzeno textem na /success) | reálné e-maily oběma účastníkům | **confirmed** (Δ31) | TC-CP-022 |
| Δ8 | OneSignal push | pravděpodobně off | reálná push doručení | legacy | mimo R1 |

## §2. Konfigurační deltové vrstvy

| # | Surface | DEMO | PROD | Confidence |
|---|---------|------|------|------------|
| Δ9 | Pojišťovny seznam | 13 entries (live capture) | shodný (stejný API endpoint) | expected |
| Δ10 | Codelisty obecně | shodné (stejný JS bundle) | shodné | expected |
| Δ11 | CSS / branding | "DEMO VERZE" + persistentní oranžový baner | čistý PROD branding | **confirmed** |
| Δ12 | CSP / cookie domains | `*.demo.bouracka.cz` | `*.bouracka.cz` | expected |
| Δ13 | Analytics IDs | TBC | live IDs | unknown |
| Δ14 | Service worker / PWA | TBC | TBC | expected |

## §3. Behaviorální deltové vrstvy

| # | Behavior | DEMO | PROD | Confidence |
|---|----------|------|------|------------|
| Δ15 | accidentReportStatus přechody | shodné | shodné | expected |
| Δ16 | Validační pravidla | shodné (regex z bundle) | shodné | expected |
| Δ17 | CS chybové hlášky | shodné | shodné | expected |
| Δ18 | PING-NOK retry | mock injectable | reálný výpadek těžko reprodukovatelný | expected |
| Δ19 | Rate limiting | TBC (dosud nepozorováno) | strict | unknown |
| Δ20 | Refresh / abandon | data-purge garance v UI copy (STR-013) | shodná garance předpoklad | expected |

## §4. Nově surfaceované deltové vrstvy z živé analýzy 2026-05-06

| # | Surface | DEMO | PROD | Confidence |
|---|---------|------|------|------------|
| Δ21 | Pre-wizard intro `/formular/informations` | přítomna (5-step "Co vás čeká?" overview) | TBC — předpoklad shodný | confirmed na DEMO |
| Δ22 | Phase-1 DEMO hint | žlutý info box "Demoverze žádné SMS neodesílá…" | MUSÍ být absent | confirmed |
| Δ23 | Google Maps locale | `intl/en_gb/` — UI v CS, mapy v EN-GB | TBC — pravděpodobně shodná vada | **confirmed (vada)** |
| Δ24 | Outage feed origin | Azure Static Web `bourackaodstavky78861.z6.web.core.windows.net` | TBC | confirmed na DEMO |
| Δ25 | API base | `demo.bouracka.cz/api/` | `bouracka.cz/api/` | expected |
| Δ26 | Report-UUID lifecycle | `POST /api/reports` mints UUID; deep-linkable; data-purge jak v UI copy | shodný kontrakt předpoklad | confirmed na DEMO |
| Δ31 | Final email rozeslání | "V Demo verzi nejsou e-maily účastníkům odesílány." | reálné rozeslání | confirmed |

## §5. Závěry

- **DEMO je vhodné** pro UX + validaci + state-machine + codelisty + většinu happy-path TC.
- **DEMO není vhodné** pro: reálné OTP testy, reálné registrové dotazy, reálné rozeslání e-mailů.
- **TC suite musí být env-aware** — nový sloupec `env_constraints` v 02_TestCases klasifikuje každý TC.
- **8 potvrzených delt** (z 26) tvoří audit-trail pro budoucí PROD-side ověření.

## §6. Status

| Item | Hodnota |
|------|---------|
| Δ rows | 26 (8 integrace + 6 konfigurace + 6 behaviorální + 6 z live walk) |
| Confirmed | 8 |
| Expected | 11 |
| Unknown | 6 |
| Legacy | 1 |
| Status | v0.3 — populates dále s PROD-side recon (Tier 2b) |
