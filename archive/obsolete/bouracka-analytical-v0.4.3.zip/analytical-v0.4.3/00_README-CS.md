# Bouračka — Analytický balíček v0.3 — Cover note

> **Audience.** SUPIN/ČKP architekti, vedoucí QA, SecOps, ČAP review board.
> **Datum.** 2026-05-06 (CP-SUPIN-04).
> **Změna proti v0.2.** Tento balíček je **přepracován zdola nahoru** z živé
> reverzní analýzy DEMO Bouračky (`demo.bouracka.cz`), která se v noci
> 2026-05-05/06 stala veřejně dostupnou. Předchozí verze (v0.1, v0.2) jsou
> uloženy v `archive/obsolete/` a označeny jako *zastaralé*.

---

## §1. Co je v balíčku

| # | Soubor | Popis | Status proti v0.2 |
|---|--------|-------|--------------------|
| 1 | `00_README-CS.md` | tento průvodní list | NEW |
| 2 | `01_TESTPLAN-CS.md` | shrnutí test-planu R1 (4 fáze + Phase 2.5 svědci) | rewritten |
| 3 | `02_DIAGRAMY-CS.md` | průvodce 3 UML diagramy + odkazy na PNG/SVG | rewritten |
| 4 | `03_TESTCASE-PREHLED-CS.md` | přehled 48 TC (23 původních + 25 nových z živé analýzy) | rewritten |
| 5 | `04_SLOVNIK-CS.md` | terminologie aktualizovaná o nové entity (RUIAN, identifikační kód, …) | refreshed |
| 6 | `05_POKRYTI-CS.md` | pokrytí TT ↔ TC (bez sirotků) | rewritten |
| 7 | `06_DELTA-DEMO-vs-PROD-CS.md` | Δ matice DEMO vs PROD (8 potvrzených, 18 očekávaných) | NEW |
| 8 | `07_INTEGRATIONS-CS.md` | 9 integrací (INT-001..INT-009; 4 nové) | NEW |
| 9 | `BOURACKA-TESTPLAN-v0.3.xlsx` | sešit 28 TT + 48 TC + env_constraints | refreshed |
| 10 | `recon/ANALYTICAL-DOC-INTELLIGENCE-v0.3.md` | analytický dokument **bottom-up** | NEW |
| 11 | `recon/flow-A1-main-tst-demo/flow.md` | end-to-end záznam živého průchodu | NEW |
| 12 | `uml/{use-case,activity,sequence}.puml` | 3 UML zdroje + (po renderu) PNG + SVG | NEW |
| 13 | `fixtures/codelists-live-2026-05-06.yaml` | 5 živě zachycených číselníků (pojišťovny 13, značky 275, …) | NEW |
| 14 | `fixtures/api-endpoints-live-2026-05-06.yaml` | katalog 23 interních + 6 externích endpointů | NEW |
| 15 | `fixtures/live-copy-strings.yaml` | 17 textových řetězců pro TC asercní | NEW |
| 16 | `MANIFEST-CS.md` | seznam souborů + SHA256 + kontrolní součet | NEW |

## §2. Klíčové nálezy z reverzní analýzy

### §2.1 Architektura

- **Frontend:** Vite + React 18+ + Zod (validace) + TanStack Query
- **Backend:** REST + JSON, UUID-keyed report resources
- **CSP-povolené 3rd-party:** Google Maps (s lokalizační vadou — viz §2.5),
  reCAPTCHA v3 invisible, ČÚZK ArcGIS pro adresy (RUIAN), Azure Static
  Web pro výpadky
- **Stack indicators:** Material UI komponenty, FileSaver.js pro PDF

### §2.2 Skutečná taxonomie procesu (oprava analytického dokumentu)

Analytický dokument popisoval 18 obrazovek (D00..D17). **Realita je 4 fáze**
s ~22 podobrazovkami:

1. **Telefonní čísla** (Phase 1) — OTP pro oba účastníky
2. **Základní údaje** (Phase 2) — OP + ŘP + adresa + e-mail (per účastník) + svědci (volitelně, Phase 2.5)
3. **Fotografie a popis nehody** (Phase 3) — fotky + poškození + pohyb + vozidlo + pojišťovna + okolnosti + místo + viník
4. **Potvrzení** (Phase 4) — souhrn + dvojí SMS-podpis + PDF

### §2.3 REST API surface — 23 interních endpointů

Detail v `07_INTEGRATIONS-CS.md`. Hlavní kategorie:
- Reports lifecycle: `POST /reports`, `GET /reports/{r}`, `GET .../completenessStatus`, `GET .../summaryId`
- Participants (per-rola): `PUT /reporter`, `POST /participants`, `GET .../participants/{p}`, `PUT .../participantData`, `PUT .../email`, `PUT .../drivingLicense/update`
- Verifikace + podpis: `POST .../sendCodeToVerify`, `POST .../verify`, `POST .../sendCodeToSign`, `POST .../sign`, `POST /session/refresh`
- Damage + okolnosti: `PUT .../damage`, `PUT .../movementDefinition`, `PUT .../vehicle`, `PUT .../insurer`, `PUT /circumstances`, `PUT /datetime`, `PUT /location`, `PUT /responsibleParticipant`
- Final: `POST /confirmation`, `GET /participantsInVerification`, `GET /participantsInSigning`, `GET /witnesses`
- Codelists (selektivní veřejnost): `GET /enumerations/{insuranceCompanies,vehicleBrands}` veřejné; 8 dalších chráněných (403)

### §2.4 Δ matice DEMO vs PROD — 8 potvrzeno z živé analýzy

| # | Δ | DEMO (potvrzeno) | PROD (předpokládáno) |
|---|---|---------|------|
| Δ1 | N8 SMS Gateway | žádné SMS, libovolný 4místný OTP přijat | reálné SMS přes N8 |
| Δ5 | zenID OCR | nahrazeno instruktážním videem | reálné OCR z OP/ŘP |
| Δ11 | Branding | "DEMO VERZE" baner + lockup | čistý PROD branding |
| Δ21 | Pre-wizard intro | obrazovka `/informations` přítomna | pravděpodobně shodné |
| Δ22 | DEMO hint v Phase 1 | žlutý box "Demoverze žádné SMS neodesílá…" | absent |
| Δ23 | Maps locale | `intl/en_gb/` (vada — má být `cs_CZ`) | shodná vada |
| Δ24 | Outage feed | `bourackaodstavky78861.z6.web.core.windows.net` | shodný |
| Δ31 | Email rozeslání | "V Demo verzi nejsou e-maily účastníkům odesílány." | reálná dopisování |

### §2.5 Vady-kandidáti k validaci s SUPIN/ČKP

1. **Google Maps locale** — celá aplikace v CS, ale mapy se načítají v
   `en_gb`. Potenciální regulátorská a UX vada. Návrh: změnit `language=cs`
   parametr ve volání Maps JS API.
2. **Identifikační kód prefix** — pozorováno `111111-26-0000001` na DEMO.
   Otázka pro ČKP: je `111111` DEMO-marker, nebo se objeví i v PROD?
3. **`?validate=false` query param** — SPA má relaxovaný validační režim
   pro automatizační účely. Otázka: je dokumentován pro testování, nebo
   jde o únik z dev cyklu?
4. **`/api/enumerations/licenseCategories` 403** — codelist je dostupný
   jen v JS bundle, ne přes REST. Otázka: záměr nebo vada?

## §3. Změny v test-planu (Excel v0.3 vs v0.2)

| Aspekt | v0.2 | v0.3 |
|--------|------|------|
| Počet TestTargets | 18 | 28 (10 nových z živé analýzy) |
| Počet TestCases | 23 | 48 (25 nových: TC-CP-NEW-A..Y) |
| Sloupec `env_constraints` | — | NEW (`both` / `demo-only` / `prod-only` / `both-with-adapter`) |
| TT/TC traceabilita | ne-validovaná | **0 sirotků** (validátor: `tools/migrate_to_v03.py`) |
| Δ matice | absent | 26 řádků (8 confirmed) |
| Live evidence | absent | end-to-end pro A1 main happy path na DEMO |

## §4. Co musí SUPIN/ČKP rozhodnout / dodat

(seřazeno podle kritičnosti)

1. **N8 SMS Gateway sandbox / skip-flag pro PROD** — zatím blokuje TC-CP-005-PROD a všechny `prod-only` TC.
2. **AISPOV (CRR/CRV/ROB) sandbox / read-only přístup pro PROD** — blokuje 5 prod-only TC.
3. **zenID test-keys** — blokuje OCR-relevantní TC.
4. **Reálný kontakt na SUPIN testera** — pro Δ ověření DEMO vs PROD.
5. **Schválení `Google Maps locale` defektu** k filování jako bug.
6. **Schválení rozsahu R1** podle verbatim copy ze DEMO rozcestníku
   (max 200 000 Kč, 2 účastníci s českými OP, bez zranění).

## §5. Stav

| Item | Hodnota |
|------|---------|
| Verze | v0.3.0 |
| Datum | 2026-05-06 |
| Coverage | A1 main happy path E2E na DEMO |
| Pending | A2..A4 alternate paths; PROD twin recon |
| Status | připraveno k SUPIN review |
