/**
 * 01-smoke.spec.ts — TC-CP-001 (bring-up smoke)
 *
 * Asserts the public DEMO Bouračka rozcestník loads, key elements visible.
 * Runs against {BOURACKA_BASE} parameter — works on any DEMO twin.
 */
import { test, expect } from '@playwright/test';

test('TC-CP-001 — Rozcestník loads + primary CTA visible', async ({ page }) => {
  await page.goto('/formular/');
  await expect(page).toHaveTitle(/Bouračka/i);
  await expect(page.getByRole('heading', { name: /Stala se vám dopravní nehoda/i })).toBeVisible();
  await expect(page.getByRole('button', { name: /Vyplnit záznam/i }).first()).toBeVisible();
});

test('TC-CP-001b — Bouračka logo + ČKP lockup present', async ({ page }) => {
  await page.goto('/formular/');
  // Logo is an SVG with brand text; check that BOURAČKA appears somewhere
  const html = await page.content();
  expect(html.toLowerCase()).toContain('bouračka');
});

test('TC-CP-001c — reCAPTCHA badge present (invisible v3)', async ({ page }) => {
  await page.goto('/formular/');
  // reCAPTCHA injects a badge with role="presentation" + iframe to www.google.com
  await page.waitForLoadState('networkidle');
  const recapBadge = page.locator('[aria-label*="reCAPTCHA"], iframe[src*="google.com/recaptcha"]');
  await expect(recapBadge.first()).toBeAttached();
});
