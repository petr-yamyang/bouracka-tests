/**
 * 04-phase1-otp.spec.ts
 *
 * TC-CP-NEW-O — DEMO accepts ANY 4-digit OTP (Δ1 confirmed)
 * TC-CP-NEW-I — GDPR consent required for participant A
 * TC-CP-NEW-H — Slovak +421 predvolba selectable
 *
 * Helper: setOtpDigits() bypasses MUI controlled-input quirks via native setter.
 */
import { test, expect, Page } from '@playwright/test';

async function navigateToVerification(page: Page) {
  await page.goto('/formular/');
  await page.getByRole('button', { name: /Vyplnit záznam/i }).first().click();
  await page.getByRole('button', { name: 'Rozumím' }).click();
  await expect(page).toHaveURL(/\/verification/);
}

async function setOtpDigits(page: Page, code: string) {
  await page.evaluate((digits: string) => {
    const inputs = document.querySelectorAll('input[type="tel"]');
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')!.set!;
    for (let i = 0; i < Math.min(inputs.length, digits.length); i++) {
      const input = inputs[i] as HTMLInputElement;
      setter.call(input, digits[i]);
      input.dispatchEvent(new Event('input', { bubbles: true }));
    }
  }, code);
}

test('TC-CP-NEW-I — Submit blocked when GDPR checkbox unchecked', async ({ page }) => {
  await navigateToVerification(page);
  await page.locator('input[type="tel"]').first().fill('608000001');
  // Do NOT check the GDPR consent
  // Try to submit — button should be disabled OR submit should not POST /reporter
  const reporterPosts: string[] = [];
  page.on('response', (r) => {
    if (r.url().includes('/reporter') && r.request().method() === 'PUT') {
      reporterPosts.push(r.url());
    }
  });
  const submitBtn = page.getByRole('button', { name: 'Odeslat kód' });
  // Attempt click — either disabled or no PUT happens
  await submitBtn.click({ trial: true }).catch(() => {});  // trial click doesn't actually click
  // Wait briefly to confirm no PUT fired
  await page.waitForTimeout(1000);
  expect(reporterPosts.length).toBe(0);
});

test('TC-CP-NEW-H — Slovak +421 predvolba is selectable in dropdown', async ({ page }) => {
  await navigateToVerification(page);
  // Open the predvolba combobox
  const predvolba = page.getByLabel(/Předvolba/i).first();
  await predvolba.click();
  // SK option should be present in dropdown
  await expect(page.getByText('+421')).toBeVisible({ timeout: 5_000 });
});

test('TC-CP-NEW-O — DEMO accepts any 4-digit OTP for participant A', async ({ page, baseURL }) => {
  test.skip(!baseURL?.includes('demo.bouracka.cz'), 'DEMO-only behaviour (Δ1)');
  await navigateToVerification(page);
  await page.locator('input[type="tel"]').first().fill('608000002');
  await page.getByRole('checkbox').first().check();
  await page.getByRole('button', { name: 'Odeslat kód' }).click();
  // Wait for OTP screen
  await expect(page.getByText('Zadejte ověřovací kód')).toBeVisible({ timeout: 10_000 });
  // Set arbitrary code via React-aware setter
  await setOtpDigits(page, '7777');
  const verifyResp = page.waitForResponse(
    (r) => r.url().includes('/verify') && r.request().method() === 'POST' && r.status() === 200,
    { timeout: 15_000 },
  );
  await page.getByRole('button', { name: 'Ověřit' }).click();
  // DEMO accepts the arbitrary code
  await verifyResp;
  // Should now show participant B form OR success state
  const next = page.getByText(/Účastník B|Ověřeno/i);
  await expect(next.first()).toBeVisible({ timeout: 10_000 });
});

test('TC-CP-NEW-O2 — DEMO hint banner present (Δ22)', async ({ page, baseURL }) => {
  test.skip(!baseURL?.includes('demo.bouracka.cz'), 'DEMO-only hint');
  await navigateToVerification(page);
  await expect(
    page.getByText('Demoverze žádné SMS neodesílá', { exact: false }),
  ).toBeVisible();
});
