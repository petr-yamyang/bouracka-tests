/**
 * 07-codelist-public.spec.ts
 *
 * TC-CP-INTEL-001 — Public enumerations (insuranceCompanies, vehicleBrands) return 200 + sane shape
 * TC-CP-INTEL-002 — Protected enumerations return 403
 * TC-CP-NEW-F — POST /api/reports envelope returns UUID-v4
 *
 * These are pure-API tests — fast and reliable. Run on both demo-public and demo-tst.
 */
import { test, expect, request } from '@playwright/test';

test('TC-CP-INTEL-001 — insuranceCompanies (public) returns ≥10 entries with code+name+ico', async ({ request, baseURL }) => {
  const r = await request.get(`${baseURL}/api/enumerations/insuranceCompanies`);
  expect(r.status()).toBe(200);
  const json = await r.json();
  expect(Array.isArray(json)).toBeTruthy();
  expect(json.length).toBeGreaterThanOrEqual(10);
  const sample = json[0];
  expect(sample).toHaveProperty('code');
  expect(sample).toHaveProperty('name');
  // ČKP-bound insurers carry IČO + claims contact
  const allianz = json.find((x: any) => x.code === 'ALLIANZ');
  expect(allianz, 'Allianz must be in the list').toBeTruthy();
  expect(allianz.description).toMatch(/^\d+$/);  // IČO is digits-only
});

test('TC-CP-INTEL-001b — vehicleBrands (public) returns 200+ brands with models[]', async ({ request, baseURL }) => {
  const r = await request.get(`${baseURL}/api/enumerations/vehicleBrands`);
  expect(r.status()).toBe(200);
  const json = await r.json();
  expect(Array.isArray(json)).toBeTruthy();
  expect(json.length).toBeGreaterThanOrEqual(200);
  // ŠKODA must be present + must have OCTAVIA model
  const skoda = json.find((x: any) => x.name === 'ŠKODA');
  expect(skoda).toBeTruthy();
  expect(skoda.models).toContain('OCTAVIA');
});

test('TC-CP-INTEL-002 — protected enumerations return 403', async ({ request, baseURL }) => {
  const protectedEnums = [
    'licenseCategories', 'damageZones', 'movementTypes',
    'accidentCauses', 'accidentCategories', 'vehicleCategories',
    'documentTypes', 'witnessTypes',
  ];
  for (const e of protectedEnums) {
    const r = await request.get(`${baseURL}/api/enumerations/${e}`);
    expect(r.status(), `${e} should be 403`).toBe(403);
  }
});

test('TC-CP-NEW-F — POST /api/reports returns UUID-v4 in body', async ({ request, baseURL }) => {
  const r = await request.post(`${baseURL}/api/reports`, {
    headers: { 'Content-Type': 'application/json' },
    data: {},  // empty body — server defaults
  });
  expect(r.status()).toBe(200);
  const text = await r.text();
  // UUID-v4 pattern (also matches the body shape we observed)
  expect(text).toMatch(/[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}/i);
});
