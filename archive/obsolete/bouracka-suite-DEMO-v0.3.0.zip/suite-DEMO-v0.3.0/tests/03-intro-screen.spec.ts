/**
 * 03-intro-screen.spec.ts
 *
 * TC-CP-NEW-E — Pre-wizard intro `/formular/informations` renders before report mint.
 *               Captures the 5-step process explanation (STR-006..009).
 */
import { test, expect } from '@playwright/test';

test('TC-CP-NEW-E — Click VYPLNIT ZÁZNAM → /informations renders 5-step list', async ({ page }) => {
  await page.goto('/formular/');
  await page.getByRole('button', { name: /Vyplnit záznam/i }).first().click();
  // URL should have changed to /informations BEFORE any /api/reports POST
  await expect(page).toHaveURL(/\/formular\/informations\/?$/);
  // STR-006
  await expect(page.getByRole('heading', { name: 'Co vás čeká?' })).toBeVisible();
  // STR-007 — single-filler-both-recipients constraint
  await expect(page.getByText('Formulář vyplňuje vždy jen jeden účastník.')).toBeVisible();
  // 5-step list
  await expect(page.getByText('Telefonní čísla')).toBeVisible();
  await expect(page.getByText('Základní údaje')).toBeVisible();
  await expect(page.getByText('Fotografie a popis nehody')).toBeVisible();
  await expect(page.getByText('Potvrzení', { exact: true })).toBeVisible();
  await expect(page.getByText('Hotovo')).toBeVisible();
  // STR-009 — acknowledgement CTA
  await expect(page.getByRole('button', { name: 'Rozumím' })).toBeVisible();
});

test('TC-CP-NEW-E2 — Clicking Rozumím triggers POST /api/reports + URL changes', async ({ page }) => {
  await page.goto('/formular/');
  await page.getByRole('button', { name: /Vyplnit záznam/i }).first().click();
  await expect(page.getByRole('button', { name: 'Rozumím' })).toBeVisible();
  // Set up a request listener BEFORE clicking
  const reportsPost = page.waitForResponse(
    (r) => r.url().endsWith('/api/reports') && r.request().method() === 'POST' && r.status() === 200,
    { timeout: 15_000 },
  );
  await page.getByRole('button', { name: 'Rozumím' }).click();
  const resp = await reportsPost;
  // Response should contain a UUID
  const body = await resp.text();
  expect(body).toMatch(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/);
  // URL should now be /report/{uuid}/verification
  await expect(page).toHaveURL(/\/report\/[0-9a-f-]{36}\/verification/);
});
