/**
 * 02-rozcestnik-copy.spec.ts
 *
 * TC-CP-NEW-A — Rozcestník copy integrity
 * TC-CP-NEW-B — R1 scope sentence verbatim
 * TC-CP-NEW-C — DEMO banner present (will fail on PROD twin — expected)
 * TC-CP-NEW-D — Police-criteria card expandable
 *
 * Ties to fixtures/live-copy-strings.yaml (STR-001..005, STR-010-cz-criteria).
 */
import { test, expect } from '@playwright/test';

test('TC-CP-NEW-A — Rozcestník headings + 3 cards visible', async ({ page }) => {
  await page.goto('/formular/');
  // STR-001 — H1
  await expect(page.getByRole('heading', { name: 'Stala se vám dopravní nehoda? To zvládnete.' })).toBeVisible();
  // STR-005 — emergency card title
  await expect(page.getByRole('heading', { name: 'Potřebujete okamžitou pomoc?' })).toBeVisible();
  // Police-criteria card title
  await expect(page.getByRole('heading', { name: 'Kdy volat Policii ČR?' }).first()).toBeVisible();
  // Primary CTA card title
  await expect(page.getByRole('heading', { name: 'Záznam o dopravní nehodě' })).toBeVisible();
});

test('TC-CP-NEW-B — R1 scope sentence verbatim (200 000 Kč anchor)', async ({ page }) => {
  await page.goto('/formular/');
  const expected = 'Vhodné pro malé nehody bez zranění a škody do 200 000 Kč vzniklé mezi 2 účastníky s českými občanskými průkazy.';
  await expect(page.getByText(expected, { exact: true })).toBeVisible();
});

test('TC-CP-NEW-C — DEMO banner: present on DEMO, absent on PROD', async ({ page, baseURL }) => {
  await page.goto('/formular/');
  const demoBanner = page.getByText('Nacházíte se v DEMO VERZI aplikace.');
  if (baseURL?.includes('demo.bouracka.cz')) {
    await expect(demoBanner).toBeVisible();
  } else {
    // PROD twin (bouracka.cz, tst.bouracka.cz) — banner MUST be absent
    await expect(demoBanner).toHaveCount(0);
  }
});

test('TC-CP-NEW-D — Police-criteria card expands to reveal 7 bullets', async ({ page }) => {
  await page.goto('/formular/');
  // Click the police card heading; assertions on revealed criteria
  await page.getByRole('heading', { name: 'Kdy volat Policii ČR?' }).first().click();
  await expect(page.getByText('Někdo je zraněný nebo došlo k úmrtí')).toBeVisible();
  await expect(page.getByText(/200 000 Kč/)).toBeVisible();
  await expect(page.getByText('Došlo ke srážce se zvěří')).toBeVisible();
  // tel: link should be present
  await expect(page.getByRole('link', { name: /158/ })).toBeVisible();
});

test('TC-CP-NEW-D2 — Safety-checklist 3 bullets visible', async ({ page }) => {
  await page.goto('/formular/');
  await expect(page.getByText('Zapněte výstražná světla a oblékněte si reflexní vestu')).toBeVisible();
  await expect(page.getByText(/výstražným trojúhelníkem/)).toBeVisible();
  await expect(page.getByText('Pokud je někdo zraněn, volejte 112')).toBeVisible();
});
