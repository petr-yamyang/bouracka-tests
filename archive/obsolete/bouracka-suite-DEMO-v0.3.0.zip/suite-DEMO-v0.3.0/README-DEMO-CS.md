# Bouračka — Test Suite "DEMO" — v0.3.0

> **Co je uvnitř.** Test sada pokrývající **VEŘEJNĚ DOSTUPNOU DEMO Bouračku
> a její firewall-gated verzi**. Suite je parametrizovaná — jeden a tentýž
> kód běží proti oběma prostředím.
>
> **Cíl.** Po rozbalení a `npm install` můžete tuto sadu spustit **OKAMŽITĚ**
> proti veřejné DEMO; následně i proti `tst.demo.bouracka.cz` (po VPN
> + průchodu firewallem).
>
> **Co tato sada NEPOKRÝVÁ.** Reálné integrační testy (skutečné SMS přes
> N8, dotazy do AISPOV registru, OCR přes zenID) — ty jsou v balíčku
> `suite-PROD-v0.3.0`.

---

## §1. Cílová prostředí

| Prostředí | URL | Síťový přístup | Použít kdy |
|-----------|-----|----------------|------------|
| `demo-public` | `https://demo.bouracka.cz` | veřejné — nikdo žádný VPN nepotřebuje | smoke + regression z laptopu |
| `demo-tst` | `https://tst.demo.bouracka.cz` | za firewallem ČKP | preprod validace před deploy do public DEMO |

Obě prostředí mají **stejný JS bundle, stejný Zod schéma, stejné chování** —
proto stejný test code. Liší se pouze base URL + případně cookie / session
posture.

## §2. Co tento balíček obsahuje

```
suite-DEMO-v0.3.0/
├── README-DEMO-CS.md                 ← tento soubor
├── package.json                      ← Playwright + jen základní deps (žádný Mockoon)
├── playwright.config.ts              ← projects matrix: 2× env × chromium-mobile
├── tsconfig.json
├── tests/
│   ├── 01-smoke.spec.ts              ← TC-CP-001 (rozcestník + reCAPTCHA)
│   ├── 02-rozcestnik-copy.spec.ts    ← TC-CP-NEW-A, B, C (copy integrity + DEMO branding)
│   ├── 03-intro-screen.spec.ts       ← TC-CP-NEW-E (pre-wizard /informations)
│   ├── 04-phase1-otp.spec.ts         ← TC-CP-NEW-O (DEMO accepts any 4-digit OTP)
│   ├── 05-phase2-manual.spec.ts      ← TC-CP-NEW-S, V, W (?validate=false + ŘP regex)
│   ├── 06-ruian-autocomplete.spec.ts ← TC-CP-NEW-U (RUIAN ČÚZK)
│   ├── 07-codelist-public.spec.ts    ← TC-CP-INTEL-001/002 (public + 403 enums)
│   ├── 08-identifikacni-kod.spec.ts  ← TC-CP-NEW-Q, R (police/IZS modal)
│   ├── 09-summary-pdf.spec.ts        ← Phase 4 PDF flow
│   └── intel-probes/                 ← read-only intel scrapes (non-mutating)
│       ├── 01-enumeration-dump.spec.ts
│       └── 02-codelist-scrape.spec.ts
├── fixtures/
│   ├── codelists-live-2026-05-06.yaml
│   ├── api-endpoints-live-2026-05-06.yaml
│   └── live-copy-strings.yaml
├── scripts/
│   ├── run-on-demo-public.ps1        ← jednorázové spuštění proti demo.bouracka.cz
│   ├── run-on-demo-tst.ps1           ← totéž proti tst.demo.bouracka.cz
│   └── run-on-both-envs.ps1          ← matrix run obou
└── MANIFEST-CS.md
```

## §3. Mapa TC ↔ env_constraints

Tato sada zahrnuje TC s `env_constraints ∈ {both, demo-only}` (z workbooku v0.3):

**Z původních 23 TC:**
- TC-CP-001 (smoke), TC-CP-002 (state machine), TC-CP-003 (resilience), TC-CP-004 (fields)
- TC-CP-007 (zenID-mocked), TC-CP-009 (ROB-sandbox), TC-CP-010 (driver-data on DEMO)
- TC-CP-011, TC-CP-012, TC-CP-013, TC-CP-014, TC-CP-015 (DEMO-mode validation)
- TC-CP-016..021, TC-CP-023

**Z 25 nových TC v0.3:**
- TC-CP-NEW-A (rozcestník copy)
- TC-CP-NEW-B (R1 scope sentence)
- TC-CP-NEW-C (DEMO banner present)
- TC-CP-NEW-D (police criteria expand)
- TC-CP-NEW-E (intro screen renders)
- TC-CP-NEW-F (POST /reports envelope)
- TC-CP-NEW-G (deep-link works)
- TC-CP-NEW-H (Slovak +421)
- TC-CP-NEW-I (GDPR asymmetric)
- TC-CP-NEW-K (data-purge)
- TC-CP-NEW-L (outage feed)
- TC-CP-NEW-M (Maps locale)
- TC-CP-NEW-O (any-4-digit OTP) — DEMO-specific
- TC-CP-NEW-Q (identifikační kód format)
- TC-CP-NEW-R (police modal)
- TC-CP-NEW-S (?validate=false)
- TC-CP-NEW-U (RUIAN autocomplete)
- TC-CP-NEW-V (ŘP regex)
- TC-CP-NEW-W (DD.MM.YYYY enforced)
- TC-CP-NEW-X (video pre-fetch non-blocking)
- TC-CP-NEW-Y (ČÚZK outage degrades)

**Vyloučeno** (jsou v `suite-PROD-v0.3.0`):
- TC-CP-005-PROD (skutečné SMS přes N8)
- TC-CP-022 (skutečné e-mail rozeslání)
- TC-CP-NEW-J (DEMO hint NEPŘÍTOMNÉ na PROD — vyžaduje PROD)
- TC-CP-NEW-P (PROD odmítá libovolný OTP)
- TC-CP-NEW-T (driver-registry s reálným AISPOV CRR)
- TC-CP-NEW-N (rate-limit ověření — PROD-only chování)

## §4. Spuštění — krok za krokem

### §4.1 Předpoklad: Node + Playwright nainstalované

Pokud ještě nemáte:

```pwsh
# Profile-C (admin)
winget install OpenJS.NodeJS.LTS

# V repo:
cd suite-DEMO-v0.3.0
npm install                    # ~ 45 s
npx playwright install chromium  # ~ 3 min
```

### §4.2 Smoke proti veřejné DEMO

```pwsh
.\scripts\run-on-demo-public.ps1
# nebo přímo:
$env:BOURACKA_BASE = "https://demo.bouracka.cz"
npx playwright test --project=demo-public
```

Očekávaný čas: ~2 min. Očekávaný výsledek: většina TC pass; prod-vyžadující TC jsou skipped.

### §4.3 Smoke proti firewall DEMO (po VPN)

```pwsh
.\scripts\run-on-demo-tst.ps1
# nebo:
$env:BOURACKA_BASE = "https://tst.demo.bouracka.cz"
npx playwright test --project=demo-tst
```

### §4.4 Matrix run obou prostředí (CI-friendly)

```pwsh
.\scripts\run-on-both-envs.ps1
# nebo:
npx playwright test
```

Playwright `playwright.config.ts` automaticky vyrobí cross-product:

```
{demo-public, demo-tst} × {chromium-mobile-375, chromium-mobile-414}
```

= 4 spouštění. HTML report pak ukáže grid kde vidíte případnou divergenci.

## §5. Velikost a e-mailové doručení

| Položka | Hodnota |
|---------|---------|
| ZIP velikost | < 1.5 MB (vejde se do nejpřísnějších scannerů) |
| Doba scanu | typicky 30-90 s na korporátním filtrem |
| Distribuce | 1× e-mail; alternativně přes SharePoint odkaz |
| Konfidenciální obsah | NE — pouze kód + metadata + verifikované veřejné endpointy |

## §6. Co dělat po prvním úspěšném běhu

1. Otevřete `playwright-report/index.html` → grid TC × env × viewport.
2. Pokud nějaký TC selže na `demo-tst` ale prošel na `demo-public`,
   je to prima signál divergence — append do
   `recon/DELTA-DEMO-vs-PROD-v0.1.md` jako nový Δ řádek.
3. Spustit intel-probes (`npx playwright test tests/intel-probes/`)
   — obohatí fixtures novými codelistovými daty z živého API.
4. Po stabilní pass-rate doplnit `suite-PROD-v0.3.0` (po dodání
   N8 sandbox + AISPOV přístupu od SUPIN/ČKP).

## §7. Status

| Item | Hodnota |
|------|---------|
| Suite | DEMO-v0.3.0 |
| Pokrytí | demo.bouracka.cz + tst.demo.bouracka.cz |
| Počet TC | ~36 (13+ původních pass-on-DEMO + 21 nových z živé analýzy) |
| Odvislost | žádný N8 / AISPOV / zenID — runnable IMMEDIATELY |
| Velikost ZIP | < 1.5 MB |
| Datum | 2026-05-06 |
