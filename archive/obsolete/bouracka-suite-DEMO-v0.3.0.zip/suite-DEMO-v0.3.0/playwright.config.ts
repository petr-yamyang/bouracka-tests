/**
 * Playwright config — Suite "DEMO" — covers public + firewall-gated DEMO twins
 *
 * Two projects (envs) × two viewports = 4 cross-product runs.
 * Use `--project=<name>` to pick one, or omit for the matrix.
 */
import { defineConfig, devices } from '@playwright/test';

const DEMO_PUBLIC = process.env.BOURACKA_BASE_DEMO_PUBLIC ?? 'https://demo.bouracka.cz';
const DEMO_TST    = process.env.BOURACKA_BASE_DEMO_TST    ?? 'https://tst.demo.bouracka.cz';

// Single-env override (when running `run-on-demo-public.ps1` etc.)
const SINGLE_ENV = process.env.BOURACKA_BASE;

export default defineConfig({
  testDir: './tests',
  timeout: 60_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,            // sequential — DEMO is shared, avoid noisy interactions
  retries: process.env.CI ? 1 : 0,
  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['json', { outputFile: 'test-results/results.json' }],
  ],
  use: {
    baseURL: SINGLE_ENV ?? DEMO_PUBLIC,
    locale: 'cs-CZ',
    timezoneId: 'Europe/Prague',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },
  projects: SINGLE_ENV
    ? [
        // Single-env mode (run-on-* script)
        {
          name: 'single-env',
          use: { ...devices['iPhone 12'], baseURL: SINGLE_ENV },
        },
      ]
    : [
        // Matrix mode (run-on-both-envs.ps1)
        {
          name: 'demo-public',
          use: {
            ...devices['iPhone 12'],
            baseURL: DEMO_PUBLIC,
          },
          metadata: { env: 'demo-public', viewport: '390x844' },
        },
        {
          name: 'demo-public-large',
          use: {
            ...devices['iPhone 14 Pro Max'],
            baseURL: DEMO_PUBLIC,
          },
          metadata: { env: 'demo-public', viewport: '430x932' },
        },
        {
          name: 'demo-tst',
          use: {
            ...devices['iPhone 12'],
            baseURL: DEMO_TST,
          },
          metadata: { env: 'demo-tst', viewport: '390x844' },
        },
        {
          name: 'demo-tst-large',
          use: {
            ...devices['iPhone 14 Pro Max'],
            baseURL: DEMO_TST,
          },
          metadata: { env: 'demo-tst', viewport: '430x932' },
        },
      ],
});
