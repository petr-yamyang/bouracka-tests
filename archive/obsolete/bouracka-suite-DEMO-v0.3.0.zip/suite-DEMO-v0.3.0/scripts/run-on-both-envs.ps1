<#
.SYNOPSIS
  Matrix run — DEMO test suite proti veřejné i firewall-gated variantě.

.DESCRIPTION
  Spustí všechny testy v cross-product:
    {demo-public, demo-public-large, demo-tst, demo-tst-large}
  HTML report pak ukáže grid pro side-by-side porovnání.

  Pokud `tst.demo.bouracka.cz` není dosažitelný, jeho projekty selžou,
  ale `demo-public-*` projekty doběhnou.

.EXAMPLE
  .\scripts\run-on-both-envs.ps1
#>
$ErrorActionPreference = 'Continue'  # don't bail on first env failure
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

# Unset BOURACKA_BASE so playwright.config.ts picks the matrix mode
Remove-Item Env:\BOURACKA_BASE -ErrorAction SilentlyContinue

Write-Host "[matrix] running 4 projects: demo-public ×2 + demo-tst ×2" -ForegroundColor Cyan
npx playwright test
$exit = $LASTEXITCODE

Write-Host ""
Write-Host "[done] HTML report: playwright-report\index.html (open for side-by-side grid)" -ForegroundColor Gray
exit $exit
