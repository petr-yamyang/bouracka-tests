<#
.SYNOPSIS
  Spustí DEMO test suite proti VEŘEJNÉ DEMO Bouračce (https://demo.bouracka.cz).

.DESCRIPTION
  Single-env run; nevyžaduje VPN. Použije matrix viewport (iPhone 12 + 14 Pro Max).

.EXAMPLE
  .\scripts\run-on-demo-public.ps1
#>
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$env:BOURACKA_BASE = "https://demo.bouracka.cz"

Write-Host "[run-on-demo-public] target=$($env:BOURACKA_BASE)" -ForegroundColor Cyan
npx playwright test --project=single-env

if ($LASTEXITCODE -eq 0) {
    Write-Host "[ok] all tests passed" -ForegroundColor Green
    Write-Host "    HTML report: playwright-report\index.html" -ForegroundColor Gray
} else {
    Write-Host "[fail] exit $LASTEXITCODE — open playwright-report\index.html for details" -ForegroundColor Red
}
exit $LASTEXITCODE
