<#
.SYNOPSIS
  Spustí DEMO test suite proti FIREWALL-GATED variantě (https://tst.demo.bouracka.cz).

.DESCRIPTION
  Single-env run; vyžaduje VPN nebo přítomnost v ČKP síti. Pokud target
  není dosažitelný, většina TC selže na DNS / TCP úrovni — ověřte
  Test-NetConnection tst.demo.bouracka.cz -Port 443 před spuštěním.

.EXAMPLE
  .\scripts\run-on-demo-tst.ps1
#>
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

$env:BOURACKA_BASE = "https://tst.demo.bouracka.cz"

Write-Host "[run-on-demo-tst] target=$($env:BOURACKA_BASE)" -ForegroundColor Cyan
Write-Host "[pre-check] Test-NetConnection..." -ForegroundColor Gray
$reach = Test-NetConnection tst.demo.bouracka.cz -Port 443 -WarningAction SilentlyContinue
if (-not $reach.TcpTestSucceeded) {
    Write-Host "[FAIL] tst.demo.bouracka.cz:443 nelze dosáhnout. Zapněte VPN nebo se připojte do sítě ČKP." -ForegroundColor Red
    exit 1
}
Write-Host "[ok] target reachable" -ForegroundColor Green

npx playwright test --project=single-env
exit $LASTEXITCODE
